# CharmeIA — Backend

Backend seguro para o CharmeIA. Protege a API Key e controla o limite de gerações.

---

## Como subir no Vercel (passo a passo)

### 1. Crie uma conta no GitHub
Acesse github.com e crie uma conta grátis se ainda não tiver.

### 2. Crie um repositório novo
- Clique em "New repository"
- Nome: `charme-ai-backend`
- Deixe como Public ou Private (tanto faz)
- Clique em "Create repository"

### 3. Suba os arquivos
Dentro do repositório criado, clique em "uploading an existing file" e suba:
- `api/generate.js`
- `package.json`
- `vercel.json`
- `.gitignore`
- `.env.example`
- `charme-ai.html`

### 4. Crie conta no Vercel
Acesse vercel.com e faça login com o GitHub.

### 5. Importe o projeto
- Clique em "Add New Project"
- Selecione o repositório `charme-ai-backend`
- Clique em "Import"

### 6. Configure as variáveis de ambiente
Antes de clicar em Deploy, vá em "Environment Variables" e adicione:

```
ANTHROPIC_API_KEY = sk-ant-SUA_CHAVE_AQUI
PRO_SECRET_TOKEN  = uma_senha_secreta_qualquer_ex_abc123xyz
NODE_ENV          = production
```

> A ANTHROPIC_API_KEY você pega em: console.anthropic.com

### 7. Deploy!
Clique em "Deploy" e aguarde ~1 minuto.

### 8. Copie a URL do seu backend
Após o deploy, o Vercel vai te dar uma URL tipo:
`https://charme-ai-backend-abc123.vercel.app`

### 9. Atualize o frontend
Abra o arquivo `charme-ai.html` e troque a linha:
```js
const BACKEND_URL = 'https://SEU-PROJETO.vercel.app/api/generate';
```
pela URL real:
```js
const BACKEND_URL = 'https://charme-ai-backend-abc123.vercel.app/api/generate';
```

### 10. Hospede o frontend no Netlify
- Acesse netlify.com
- Arraste o arquivo `charme-ai.html` atualizado
- Pronto! Seu site está no ar com backend seguro.

---

## Como funciona o controle de planos

**Usuário Free:**
- 5 gerações por dia (por IP)
- Após o limite, aparece botão para assinar PRO

**Usuário PRO:**
- Gerações ilimitadas
- Precisa passar o token no header: `Authorization: Bearer SEU_PRO_SECRET_TOKEN`

**Como dar acesso PRO ao cliente:**
1. Cliente paga via Kiwify ou Mercado Pago
2. Você envia manualmente o `PRO_SECRET_TOKEN` por e-mail
3. O site salva o token no localStorage do cliente

> Em versão futura, isso pode ser automatizado via webhook de pagamento.

---

## Estrutura do projeto

```
charme-ai-backend/
├── api/
│   └── generate.js     ← Backend principal (API Key fica aqui)
├── charme-ai.html      ← Frontend atualizado
├── package.json
├── vercel.json         ← Configuração do Vercel
├── .env.example        ← Modelo das variáveis de ambiente
├── .gitignore
└── README.md
```

---

## Segurança implementada

- API Key nunca exposta no frontend
- Rate limiting por IP (5/dia no Free)
- Validação de tamanho da imagem (máx 5MB)
- CORS configurado
- Erros não expõem detalhes internos em produção

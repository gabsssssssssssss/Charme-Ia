const Anthropic = require('@anthropic-ai/sdk');

// ── RATE LIMIT em memória (reinicia se o servidor reiniciar)
// Para produção real, use Redis ou Supabase
const usageMap = new Map();

function getUsageKey(ip) {
  const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
  return `${ip}_${today}`;
}

function getUsageCount(ip) {
  return usageMap.get(getUsageKey(ip)) || 0;
}

function incrementUsage(ip) {
  const key = getUsageKey(ip);
  usageMap.set(key, (usageMap.get(key) || 0) + 1);
}

// ── HANDLER PRINCIPAL
module.exports = async function handler(req, res) {
  // CORS — permite seu frontend acessar
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Método não permitido' });
  }

  try {
    // ── PEGA IP DO CLIENTE
    const ip =
      req.headers['x-forwarded-for']?.split(',')[0] ||
      req.headers['x-real-ip'] ||
      req.socket?.remoteAddress ||
      'unknown';

    // ── PEGA TOKEN DE AUTENTICAÇÃO (se tiver plano PRO)
    const authHeader = req.headers['authorization'] || '';
    const proToken = authHeader.replace('Bearer ', '').trim();
    const isPro = proToken === process.env.PRO_SECRET_TOKEN;

    // ── VERIFICA LIMITE (Free = 5/dia, PRO = ilimitado)
    const FREE_LIMIT = 5;
    const usage = getUsageCount(ip);

    if (!isPro && usage >= FREE_LIMIT) {
      return res.status(429).json({
        error: 'limite_atingido',
        message: `Você atingiu o limite de ${FREE_LIMIT} gerações grátis por dia. Assine o PRO para gerações ilimitadas!`,
        usage,
        limit: FREE_LIMIT,
      });
    }

    // ── VALIDA BODY
    const { imageBase64, style, tom } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Imagem não enviada' });
    }

    if (typeof imageBase64 !== 'string' || imageBase64.length > 5 * 1024 * 1024) {
      return res.status(400).json({ error: 'Imagem inválida ou muito grande (máx 5MB)' });
    }

    // ── CHAMA A API DO CLAUDE (API Key fica só aqui no servidor!)
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

    const prompt = `Você é um assistente criativo especializado em comunicação social e marketing pessoal. Analise a imagem enviada e crie 4 comentários criativos que alguém poderia postar nessa foto para iniciar uma conversa ou chamar atenção de forma positiva.

Estilo desejado: "${style || 'ousado'}", tom: "${tom || 'leve'}".

IMPORTANTE: Retorne APENAS o JSON abaixo, sem nenhum texto antes ou depois, sem markdown:
{"comments":[{"tag":"ousado","text":"comentário aqui"},{"tag":"engraçado","text":"comentário aqui"},{"tag":"misterioso","text":"comentário aqui"},{"tag":"direto","text":"comentário aqui"}]}

Diretrizes:
- Se houver pessoa na foto, baseie os comentários em elementos visuais como roupa, cenário, expressão, postura
- Se não houver pessoa, crie comentários elogiando o momento, o lugar ou o estilo da foto
- Máximo 2 frases por comentário
- Português brasileiro coloquial e natural
- Tom respeitoso e positivo
- Cada comentário deve ter um gancho que convide à resposta`;

    const response = await client.messages.create({
      model: 'claude-sonnet-4-20250514',
      max_tokens: 1000,
      messages: [{
        role: 'user',
        content: [
          {
            type: 'image',
            source: { type: 'base64', media_type: 'image/jpeg', data: imageBase64 }
          },
          { type: 'text', text: prompt }
        ]
      }]
    });

    // ── PARSEIA RESPOSTA
    const raw = response.content.map(i => i.text || '').join('');
    const clean = raw.replace(/```json|```/g, '').trim();
    const jsonMatch = clean.match(/\{[\s\S]*\}/);

    if (!jsonMatch) {
      return res.status(500).json({ error: 'A IA não retornou um formato válido. Tente novamente.' });
    }

    const parsed = JSON.parse(jsonMatch[0]);

    // ── INCREMENTA USO SÓ APÓS SUCESSO
    if (!isPro) incrementUsage(ip);

    // ── RETORNA COMENTÁRIOS + INFO DE USO
    return res.status(200).json({
      ...parsed,
      usage: isPro ? null : getUsageCount(ip),
      limit: isPro ? null : FREE_LIMIT,
      isPro,
    });

  } catch (err) {
    console.error('Erro no handler:', err);

    if (err.status === 400) {
      return res.status(400).json({ error: 'Imagem inválida ou não suportada pela IA.' });
    }

    return res.status(500).json({
      error: 'Erro interno do servidor. Tente novamente.',
      detail: process.env.NODE_ENV === 'development' ? err.message : undefined,
    });
  }
};
